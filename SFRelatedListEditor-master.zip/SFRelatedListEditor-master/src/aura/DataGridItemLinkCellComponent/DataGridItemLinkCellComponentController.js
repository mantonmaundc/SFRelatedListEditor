({
    doInit : function(component, event, helper) {              
        helper.doInit(component, event); 
        helper.doCustomInit(component, event); 
    }
})