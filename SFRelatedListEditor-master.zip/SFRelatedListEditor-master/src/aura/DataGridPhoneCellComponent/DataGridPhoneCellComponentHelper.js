({
    customCheckInput : function(cellInput, component, event){
        this.checkRequired(cellInput, component, event);   
    }
})